﻿using System;
namespace BSTPA1
{
    public class BinTree
    {
        public BinTree()
        {
        }
    }
}
