﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Diagnostics;


namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> rand = new List<int>();
            List<int> rand2 = new List<int>();
            Stopwatch stopwatch = new Stopwatch();
            Console.WriteLine("Starting Tests of Merge Sort vs. Threaded Merge Sort");
            Console.WriteLine("Array Sizes under test [ 8, 64, 256, 1024]");
            Random make = new Random();
            // Make random of n values (done multiple times for 8,64,256,1024)
            for (int i = 0; i < 8; i++)
            {
                rand.Add(make.Next(0, Int32.MaxValue));
            }
            rand2 = rand;
            // Get time before
            // before = DateTimeOffset.Now.ToUniversalTime().Millisecond;
            stopwatch.Start();
            // Run Sort
            List<int> print = MergeSort(rand);
            // Get time after
            stopwatch.Stop();
          //After = DateTimeOffset.Now.ToUniversalTime().Millisecond;
            // Display regular results
            Console.WriteLine("Test at 8 entries: ");
            Console.WriteLine("\tNormal Sort (ms) = " + stopwatch.ElapsedMilliseconds.ToString());
            // Repeat for threaded sort
            stopwatch.Reset();
            stopwatch.Start();
            print = ThreadedMergeSort(rand2);
            stopwatch.Stop();
            // Display threaded results
            Console.WriteLine("\tThreaded Sort (ms) = " + stopwatch.ElapsedMilliseconds.ToString());
            // Clear previous values in random lists
            rand.Clear();
            rand2.Clear();
            // Repeat above steps for 64, 256, and 1024
            for (int i = 0; i < 64; i++)
            {
                rand.Add(make.Next(0, Int32.MaxValue));
            }
            rand2 = rand;
            stopwatch.Reset();
            stopwatch.Start();
            print = MergeSort(rand);
            stopwatch.Stop();
            Console.WriteLine("Test at 64 entries: ");
            Console.WriteLine("\tNormal Sort (ms) = " + stopwatch.ElapsedMilliseconds.ToString());
            stopwatch.Reset();
            stopwatch.Start();
            print = ThreadedMergeSort(rand2);
            stopwatch.Stop();
            Console.WriteLine("\tThreaded Sort (ms) = " + stopwatch.ElapsedMilliseconds.ToString());
            rand.Clear();
            rand2.Clear();
            for (int i = 0; i < 256; i++)
            {
                rand.Add(make.Next(0, Int32.MaxValue));
            }
            rand2 = rand;
            stopwatch.Reset();
            stopwatch.Start();
            print = MergeSort(rand);
            stopwatch.Stop();
            Console.WriteLine("Test at 256 entries: ");
            Console.WriteLine("\tNormal Sort (ms) = " + stopwatch.ElapsedMilliseconds.ToString());
            stopwatch.Reset();
            stopwatch.Start();
            print = ThreadedMergeSort(rand2);
            stopwatch.Stop();
            Console.WriteLine("\tThreaded Sort (ms) = " + stopwatch.ElapsedMilliseconds.ToString());
            rand.Clear();
            rand2.Clear();
            for (int i = 0; i < 1024; i++)
            {
                rand.Add(make.Next(0, Int32.MaxValue));
            }
            rand2 = rand;
            stopwatch.Reset();
            stopwatch.Start();
            print = MergeSort(rand);
            stopwatch.Stop();
            Console.WriteLine("Test at 1024 entries: ");
            Console.WriteLine("\tNormal Sort (ms) = " + stopwatch.ElapsedMilliseconds.ToString());
            stopwatch.Reset();
            stopwatch.Start();
            print = ThreadedMergeSort(rand2);
            stopwatch.Stop();
            Console.WriteLine("\tThreaded Sort (ms) = " + stopwatch.ElapsedMilliseconds.ToString());
            rand.Clear();
            rand2.Clear();
        }

        static List<int> MergeSort(List<int> sort)
        {
            // Two lists for holding
            List<int> hold = new List<int>();
            List<int> hold2 = new List<int>();
            // If single value simply return
            if (sort.Count <= 1)
            {
                return sort;
            }
            // Otherwise split provided list over two hold lists
            int mid = sort.Count / 2;
            for(int i = 0; i < mid; i++)
            {
                hold.Add(sort[i]);
            }
            for (int i = mid; i < sort.Count; i++)
            {
                hold2.Add(sort[i]);
            }
            // Call MergeSort on hold lists
            hold = MergeSort(hold);
            hold2 = MergeSort(hold2);
            // Create new list to return 
            List<int> res = new List<int>();
            while(hold.Count > 0 || hold2.Count > 0)
            {
                // Check cases, if both lists have at least one value check here
                if(hold.Count > 0 && hold2.Count > 0)
                {
                    // Compare first value in each list and add lowest to new list
                    if(hold.First() < hold2.First())
                    {
                        res.Add(hold.First());
                        hold.Remove(hold.First());
                    }
                    else
                    {
                        res.Add(hold2.First());
                        hold2.Remove(hold2.First());
                    }
                }
                // If one list is at 0 count we automatically add all values from the other list
                else if (hold.Count > 0)
                {
                    res.Add(hold.First());
                    hold.Remove(hold.First());
                }
                else if (hold2.Count > 0)
                {
                    res.Add(hold2.First());
                    hold2.Remove(hold2.First());
                }
            }
            // Return the resulting list
            return res;
        }

        // Essentially the same as above but with threads added at function calls
        static List<int> ThreadedMergeSort(List<int> sort)
        {
            List<int> hold = new List<int>();
            List<int> hold2 = new List<int>();
            if (sort.Count <= 1)
            {
                return sort;
            }
            int mid = sort.Count / 2;
            for (int i = 0; i < mid; i++)
            {
                hold.Add(sort[i]);
            }
            for (int i = mid; i < sort.Count; i++)
            {
                hold2.Add(sort[i]);
            }
            // Make thread for function call threadedmergesort, also sets the return of the call to hold and hold2 
            Thread Thold = new Thread(o => { hold = ThreadedMergeSort((List<int>)o); });
            Thold.Start(hold);
            Thread Thold2 = new Thread(o => { hold2 = ThreadedMergeSort((List<int>)o); });
            Thold2.Start(hold2);
            // Have to wait until both have finished before continuing since both return lists needed
            Thold.Join();
            Thold2.Join();
            // From here carry on as before
            List<int> res = new List<int>();
            while (hold.Count > 0 || hold2.Count > 0)
            {
                if (hold.Count > 0 && hold2.Count > 0)
                {
                    if (hold.First() < hold2.First())
                    {
                        res.Add(hold.First());
                        hold.Remove(hold.First());
                    }
                    else
                    {
                        res.Add(hold2.First());
                        hold2.Remove(hold2.First());
                    }
                }
                else if (hold.Count > 0)
                {
                    res.Add(hold.First());
                    hold.Remove(hold.First());
                }
                else if (hold2.Count > 0)
                {
                    res.Add(hold2.First());
                    hold2.Remove(hold2.First());
                }
            }
            return res;
        }
    }
}
